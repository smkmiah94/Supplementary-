<?php


$username =$_POST['user'];
$password = $_POST['pass'];




//$username = stripcslashes ($username);
//$password = stripcslashes ($password);

//$username = mysql_escape_string ($username);
//$password = mysql_escape_string ($password);

echo $username; 
echo $password; 

    
$mysqli = new mysqli("localhost", "root", "", "rkali");

$result = mysql_query("select * from users where username = '$username' and password = '$password'")
    or die ("Failed to query database" .mysql_error());


$row = mysql_fetch_array($result);

if ($row['username'] == $username && $row['password'] == $password ) {
    echo "Login Successful!!! Welcome " .$row['username'];
        
}else {
    echo "Failed to login!";
    
}



?>